-- ═══════════════════════════════════════════════════════════════════════════
-- CONSOLIDATED DATABASE SCHEMA — Personal Flight Log
-- ═══════════════════════════════════════════════════════════════════════════

-- ─── 1. CLEANUP (Opcional para recreación completa) ────────────────────────
-- DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
-- DROP FUNCTION IF EXISTS handle_new_user();
-- DROP TABLE IF EXISTS public.calendar_tokens CASCADE;
-- DROP TABLE IF EXISTS public.flight_logs CASCADE;
-- DROP TABLE IF EXISTS public.profiles CASCADE;
-- DROP TABLE IF EXISTS public.airports CASCADE;
-- DROP TABLE IF EXISTS public.pending_registrations CASCADE;
-- DROP TABLE IF EXISTS public.user_remote_sessions CASCADE;
-- DROP TABLE IF EXISTS public.app_config CASCADE;
-- DROP TABLE IF EXISTS public.arms_roster CASCADE;
-- DROP TABLE IF EXISTS public.arms_sessions CASCADE;
-- DROP TABLE IF EXISTS public.bug_reports CASCADE;
-- DROP TABLE IF EXISTS public.push_tokens CASCADE;

-- ─── 2. TABLA: profiles ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  first_name TEXT,
  last_name TEXT,
  email TEXT,
  legajo TEXT,
  license TEXT,
  dni TEXT,
  initial_folio_number INTEGER DEFAULT 1,
  initial_total_hours NUMERIC DEFAULT 0,
  total_airfield_day_pilot NUMERIC DEFAULT 0,
  total_airfield_day_copilot NUMERIC DEFAULT 0,
  total_airfield_night_pilot NUMERIC DEFAULT 0,
  total_airfield_night_copilot NUMERIC DEFAULT 0,
  total_cross_country_day_pilot NUMERIC DEFAULT 0,
  total_cross_country_day_copilot NUMERIC DEFAULT 0,
  total_cross_country_night_pilot NUMERIC DEFAULT 0,
  total_cross_country_night_copilot NUMERIC DEFAULT 0,
  total_landings INTEGER DEFAULT 0,
  total_instruction_time NUMERIC DEFAULT 0,
  total_multi_engine NUMERIC DEFAULT 0,
  total_jet NUMERIC DEFAULT 0,
  total_turboprop NUMERIC DEFAULT 0,
  total_ag_application NUMERIC DEFAULT 0,
  total_ifr_real_pilot NUMERIC DEFAULT 0,
  total_ifr_real_copilot NUMERIC DEFAULT 0,
  total_ifr_hood NUMERIC DEFAULT 0,
  total_sim_instructor NUMERIC DEFAULT 0,
  total_sim_student NUMERIC DEFAULT 0,
  grand_total_hours NUMERIC DEFAULT 0,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_synced_flight_at TIMESTAMP WITH TIME ZONE,
  subscription_id TEXT,
  subscription_end_date TIMESTAMP WITH TIME ZONE,
  subscription_status TEXT,
  mp_payer_email TEXT,
  role TEXT DEFAULT 'piloto_fb'
);

-- ─── 3. TABLA: airports ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.airports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  iata_code TEXT UNIQUE NOT NULL,
  icao_code TEXT UNIQUE NOT NULL,
  anac_code TEXT UNIQUE,
  name TEXT NOT NULL,
  city TEXT,
  country TEXT DEFAULT 'Argentina'
);

-- ─── 4. TABLA: flight_logs ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.flight_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users ON DELETE CASCADE NOT NULL,
  "fechaHoraSalida" TIMESTAMP WITH TIME ZONE NOT NULL,
  "fechaHoraLlegada" TIMESTAMP WITH TIME ZONE NOT NULL,
  "origenID" TEXT NOT NULL,
  "origenPersonalizado" TEXT DEFAULT '',
  "destinoID" TEXT NOT NULL,
  "destinoPersonalizado" TEXT DEFAULT '',
  "finalidadID" TEXT,
  "clase" TEXT,
  "matriculaAvion" TEXT,
  "potencia" INTEGER DEFAULT 0,
  "aterrizajes" INTEGER DEFAULT 1,
  "horasDia" TEXT DEFAULT '0',
  "horasNoche" TEXT DEFAULT '0',
  "tipoVueloID" TEXT,
  "cargoID" TEXT,
  "autoridadCertificanteID" TEXT,
  "observaciones" TEXT,
  "Discriminaciones" JSONB DEFAULT '[]',
  "folio_number" INTEGER DEFAULT 1,
  "is_capota" BOOLEAN DEFAULT FALSE,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  "multi_engine" NUMERIC DEFAULT 0,
  "jet" NUMERIC DEFAULT 0,
  "turboprop" NUMERIC DEFAULT 0,
  "ifr_instrument" NUMERIC DEFAULT 0,
  "instruccion" NUMERIC DEFAULT 0,
  "airfield_day_pilot" NUMERIC DEFAULT 0,
  "airfield_day_copilot" NUMERIC DEFAULT 0,
  "airfield_night_pilot" NUMERIC DEFAULT 0,
  "airfield_night_copilot" NUMERIC DEFAULT 0,
  "cross_country_day_pilot" NUMERIC DEFAULT 0,
  "cross_country_day_copilot" NUMERIC DEFAULT 0,
  "cross_country_night_pilot" NUMERIC DEFAULT 0,
  "cross_country_night_copilot" NUMERIC DEFAULT 0,
  "ifr_real_pilot" NUMERIC DEFAULT 0,
  "ifr_real_copilot" NUMERIC DEFAULT 0,
  "ifr_hood" NUMERIC DEFAULT 0,
  "sim_instructor" NUMERIC DEFAULT 0,
  "sim_student" NUMERIC DEFAULT 0,
  "ag_application" NUMERIC DEFAULT 0,
  "Marca_Modelo" TEXT
);

-- ─── 5. TABLA: pending_registrations ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.pending_registrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  first_name TEXT,
  last_name TEXT,
  license TEXT,
  dni TEXT,
  legajo TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ─── 6. TABLA: user_remote_sessions ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.user_remote_sessions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users ON DELETE CASCADE NOT NULL,
  session_data JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ─── 7. TABLA: app_config ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.app_config (
  key TEXT PRIMARY KEY,
  value TEXT
);

-- ─── 8. TABLA: arms_roster ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.arms_roster (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users ON DELETE CASCADE NOT NULL,
  month INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
  year INTEGER NOT NULL CHECK (year BETWEEN 2020 AND 2099),
  synced_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  roster_json JSONB NOT NULL DEFAULT '[]'::jsonb,
  roster_hash TEXT,
  UNIQUE(user_id, month, year)
);

-- ─── 9. TABLA: arms_sessions ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.arms_sessions (
  user_id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  session_data JSONB,
  arms_username TEXT,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ─── 10. TABLA: bug_reports ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.bug_reports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ─── 11. TABLA: push_tokens ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.push_tokens (
  user_id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  fcm_token TEXT NOT NULL,
  platform TEXT DEFAULT 'android',
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ─── 12. TABLA: calendar_tokens ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.calendar_tokens (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users ON DELETE CASCADE NOT NULL,
  token TEXT UNIQUE NOT NULL,
  label TEXT DEFAULT 'Sin nombre'::text,
  settings JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  revoked_at TIMESTAMP WITH TIME ZONE,
  user_email TEXT
);

-- ─── 13. ÍNDICES ──────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_arms_roster_user_id ON public.arms_roster USING btree (user_id);
CREATE INDEX IF NOT EXISTS idx_arms_roster_user_period ON public.arms_roster USING btree (user_id, year, month);
CREATE INDEX IF NOT EXISTS idx_calendar_tokens_token ON public.calendar_tokens USING btree (token);
CREATE INDEX IF NOT EXISTS idx_calendar_tokens_user_id ON public.calendar_tokens USING btree (user_id);
CREATE INDEX IF NOT EXISTS idx_flight_logs_user_id ON public.flight_logs USING btree (user_id);

-- ─── 14. TRIGGER Y FUNCIÓN DE AUTOMATIZACIÓN ──────────────────────────────
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, first_name, last_name, legajo, license, dni, role)
  VALUES (
    NEW.id, 
    NEW.email, 
    COALESCE(NEW.raw_user_meta_data->>'first_name', ''), 
    COALESCE(NEW.raw_user_meta_data->>'last_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'legajo', ''),
    COALESCE(NEW.raw_user_meta_data->>'license', ''),
    COALESCE(NEW.raw_user_meta_data->>'dni', ''),
    COALESCE(NEW.raw_user_meta_data->>'role', 'piloto_fb')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- ─── 15. SEGURIDAD: ROW LEVEL SECURITY (RLS) ──────────────────────────────
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.flight_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.airports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.arms_roster ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.arms_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.push_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.calendar_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_remote_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pending_registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bug_reports ENABLE ROW LEVEL SECURITY;

-- ─── 16. POLÍTICAS RLS ────────────────────────────────────────────────────
DROP POLICY IF EXISTS "Users can access their own profile" ON public.profiles;
CREATE POLICY "Users can access their own profile" ON public.profiles FOR ALL USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can access their own flight logs" ON public.flight_logs;
CREATE POLICY "Users can access their own flight logs" ON public.flight_logs FOR ALL USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Public read for airports" ON public.airports;
CREATE POLICY "Public read for airports" ON public.airports FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users manage own roster" ON public.arms_roster;
CREATE POLICY "Users manage own roster" ON public.arms_roster FOR ALL USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users manage own arms session" ON public.arms_sessions;
CREATE POLICY "Users manage own arms session" ON public.arms_sessions FOR ALL USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users manage own push tokens" ON public.push_tokens;
CREATE POLICY "Users manage own push tokens" ON public.push_tokens FOR ALL USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "users_select_own_tokens" ON public.calendar_tokens;
CREATE POLICY "users_select_own_tokens" ON public.calendar_tokens FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "users_insert_own_tokens" ON public.calendar_tokens;
CREATE POLICY "users_insert_own_tokens" ON public.calendar_tokens FOR INSERT WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "users_update_own_tokens" ON public.calendar_tokens;
CREATE POLICY "users_update_own_tokens" ON public.calendar_tokens FOR UPDATE USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "users_delete_own_tokens" ON public.calendar_tokens;
CREATE POLICY "users_delete_own_tokens" ON public.calendar_tokens FOR DELETE USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "service_role_access" ON public.user_remote_sessions;
CREATE POLICY "service_role_access" ON public.user_remote_sessions FOR ALL USING (auth.uid() = user_id);


-- ═══════════════════════════════════════════════════════════════════════════
-- SECCIÓN: INSERCIÓN DE DATOS DE LAS TABLAS
-- ═══════════════════════════════════════════════════════════════════════════

SET session_replication_role = 'replica';

TRUNCATE TABLE public.airports CASCADE;
TRUNCATE TABLE public.profiles CASCADE;
TRUNCATE TABLE public.flight_logs CASCADE;
TRUNCATE TABLE public.pending_registrations CASCADE;
TRUNCATE TABLE public.user_remote_sessions CASCADE;
TRUNCATE TABLE public.app_config CASCADE;
TRUNCATE TABLE public.arms_roster CASCADE;
TRUNCATE TABLE public.arms_sessions CASCADE;
TRUNCATE TABLE public.bug_reports CASCADE;
TRUNCATE TABLE public.push_tokens CASCADE;
TRUNCATE TABLE public.calendar_tokens CASCADE;

-- Datos para airports
INSERT INTO public.airports ("id", "iata_code", "icao_code", "anac_code", "name", "city", "country") VALUES
  ('9ab4c2ba-9c0b-4297-afe8-242ac6ac0675', 'AER', 'URSS', '', 'Sochi International Airport', 'Sochi', 'Russia'),
  ('1525401b-46f0-4fd2-bc26-30777f8d8931', 'EZE', 'SAEZ', 'EZE', 'Ministro Pistarini', 'Ezeiza', 'Argentina'),
  ('c3e56a23-a70a-418e-9e2b-8c3c0a5b1ca7', 'SDE', 'SANE', 'SDE', 'Vicecomodoro Ángel de la Paz Aragonés', 'Santiago del Estero', 'Argentina'),
  ('af6da78c-1ffd-4da4-b6e2-84b67f34d4cc', 'JUJ', 'SASJ', 'JUJ', 'Gobernador Horacio Guzmán', 'San Salvador de Jujuy', 'Argentina'),
  ('ae860f25-a8ea-44c7-a066-263ae9a8bc98', 'TUC', 'SANT', 'TUC', 'Teniente Benjamín Matienzo', 'San Miguel de Tucumán', 'Argentina'),
  ('93cb70a5-5c38-48db-8d6e-3bc620d04b39', 'COR', 'SACO', 'COR', 'Ingeniero Aeronáutico Ambrosio L.V. Taravella', 'Córdoba', 'Argentina'),
  ('d14caf2e-d4a9-4bba-a838-f4521b0d696c', 'MDZ', 'SAME', 'MDZ', 'Gobernador Francisco Gabrielli', 'Mendoza', 'Argentina'),
  ('c0ed6ab4-6555-45a4-9f9a-5d59064e1e62', 'BRC', 'SAZS', 'BRC', 'San Carlos de Bariloche', 'San Carlos de Bariloche', 'Argentina'),
  ('e41e93f6-60b9-499a-ae96-95eac71a06e0', 'IGR', 'SARI', 'IGR', 'Cataratas del Iguazú', 'Puerto Iguazú', 'Argentina'),
  ('049c5680-d153-4f95-84fe-b88024929b89', 'JUA', 'SJUV', 'JUA', 'Juazeiro do Norte', 'Juazeiro do Norte', 'Brazil'),
  ('103b4bb6-90d9-445f-90e0-e2a015f106f4', 'CBA', 'SAC', 'CBA', 'Ing. Aer. A.L.V. Taravella', 'Córdoba', 'Argentina'),
  ('f75aed2c-0692-4cc3-8df3-3147e3dabc69', 'SAL', 'MSLP', 'SAL', 'Monseñor Óscar Arnulfo Romero y Galdámez', 'San Salvador', 'El Salvador'),
  ('4692b6b8-4418-4baf-be6c-70070b150cf3', 'IGU', 'SBFI', 'IGU', 'Cataratas', 'Foz do Iguaçu', 'Brazil'),
  ('b9a97aa7-b03f-4cd7-a57b-5c8c2414e8f8', 'DOZ', 'YDOZ', 'DOZ', 'Dorothy Creek', 'Dorothy Creek', 'Australia'),
  ('da27f9b0-32cf-4e86-a4ea-27a3c3522556', 'PAL', 'SKPL', 'PAL', 'Palanquero', 'Palanquero', 'Colombia'),
  ('31932504-d7f9-4ee7-9bb4-a87073b6dc82', 'BAR', 'SABA', 'BAR', 'La Bengala', 'La Bengala', 'Argentina'),
  ('b169e75e-847c-42da-9138-7952cd4c41de', 'ECA', 'KECA', 'ECA', 'Los Charrúas', 'Los Charrúas', 'Argentina'),
  ('bca2a802-9b1f-4e8c-840e-8b6e2fe155ab', 'FDO', 'SADF', 'FDO', 'La Boca', 'La Boca', 'Argentina');

-- Datos para profiles
INSERT INTO public.profiles ("id", "first_name", "last_name", "email", "legajo", "license", "dni", "initial_folio_number", "initial_total_hours", "total_airfield_day_pilot", "total_airfield_day_copilot", "total_airfield_night_pilot", "total_airfield_night_copilot", "total_cross_country_day_pilot", "total_cross_country_day_copilot", "total_cross_country_night_pilot", "total_cross_country_night_copilot", "total_landings", "total_instruction_time", "total_multi_engine", "total_jet", "total_turboprop", "total_ag_application", "total_ifr_real_pilot", "total_ifr_real_copilot", "total_ifr_hood", "total_sim_instructor", "total_sim_student", "grand_total_hours", "updated_at", "last_synced_flight_at", "subscription_id", "subscription_end_date", "subscription_status", "mp_payer_email", "role", "calendar_settings") VALUES
  ('61ad7088-ae59-4d04-ab3b-1a94ce1316b8', 'Carolina', 'Levar', 'carolina.levar@flybondi.com', '65', 'Tcp', '34145670', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2026-07-15T08:30:58.642918+00:00', NULL, NULL, '2026-08-16T19:50:18.461542+00:00', 'trial', NULL, 'tcp_fb', '{}'::jsonb),
  ('2289fbc0-fc71-4e04-80ca-a023de7839a5', 'Adrian', 'Oviedo', 'chimuoviedo@hotmail.com', '82566', 'TLA', '28659452', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2026-07-16T20:38:36.322284+00:00', NULL, NULL, '2026-08-16T19:50:18.461542+00:00', 'trial', NULL, 'piloto_fb', '{}'::jsonb),
  ('3bee64a2-406e-4848-b5cb-b900d7234189', 'Ariel', 'Bassetere', 'arielbasseterre@outlook.com', '1291', 'nonaplica', '29327413', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2026-06-28T02:28:24.402961+00:00', NULL, NULL, '2026-08-15T19:50:18.461542+00:00', 'trial', NULL, 'tcp_fb', '{}'::jsonb),
  ('6c844565-e294-4a34-a23f-cd79313f5a51', 'Vale', 'La', 'valeriabasseterre@hotmail.com', '1', '1', '1111', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2026-07-18T02:37:27.657859+00:00', NULL, '8dde3d47adc54b789db3d004899c8883', '2027-08-17T02:37:27.74+00:00', 'authorized', NULL, 'piloto_fb', '{}'::jsonb),
  ('2cc699b7-38e2-4499-89a2-e2c9f1b63129', 'Ariel', 'Basseterre', 'arielbasseterre@gmail.com', '82468', 'TLA', '29327413', 47, 1833.4, 2.8, 0, 0, 0, 543.3, 678, 194.4, 414.9, 980, 0, 1830.6, 1735.1, 78.8, 0, 569.9, 993.5, 0, 0, 126, 1896.9, '2026-05-01T22:56:43.4418+00:00', '2026-07-17T21:15:00+00:00', '3c2e939800034f81a92769936ce23d15', '2028-07-06T17:26:11+00:00', 'authorized', 'valeriabasseterre@hotmail.com', 'piloto_fb', '{"excludeGTR":false,"excludeNDA":false,"excludeOTH":false,"excludeCrew":false,"excludeLeave":false,"excludeDayOff":false,"excludeLayover":false,"excludeStandby":false,"aggregateFlights":false,"flightEventFormat":"route_flight_times","postFlightMinutes":0,"reportEventFormat":"type_info","exportTodayOnwards":false}'::jsonb),
  ('d72b2ab2-13fc-4953-81f9-db6303189e95', 'Pedro', 'Morelli', 'pedromorelli72744@hotmail.com', '72744', 'TLA', '32699706', 2, 6213.7, 1972.9, 0, 253.7, 0, 2207, 703.7, 673.9000000000001, 445.9, 8912, 2062.7, 3628.6, 2420.8, 1130, 0, 1645.5, 1024.4, 54.9, 0, 200, 14733.5, '2026-05-04T20:37:42.036217+00:00', '2026-07-12T10:00:00+00:00', 'fbed2d324f06460c9438c62e9f51afb7', '2027-08-15T19:50:18.461+00:00', 'authorized', NULL, 'piloto_fb', '{}'::jsonb);

-- Datos para flight_logs
INSERT INTO public.flight_logs ("id", "user_id", "fechaHoraSalida", "fechaHoraLlegada", "origenID", "origenPersonalizado", "destinoID", "destinoPersonalizado", "finalidadID", "clase", "matriculaAvion", "potencia", "aterrizajes", "horasDia", "horasNoche", "tipoVueloID", "cargoID", "autoridadCertificanteID", "observaciones", "Discriminaciones", "folio_number", "is_capota", "created_at", "multi_engine", "jet", "turboprop", "ifr_instrument", "instruccion", "airfield_day_pilot", "airfield_day_copilot", "airfield_night_pilot", "airfield_night_copilot", "cross_country_day_pilot", "cross_country_day_copilot", "cross_country_night_pilot", "cross_country_night_copilot", "ifr_real_pilot", "ifr_real_copilot", "ifr_hood", "sim_instructor", "sim_student", "ag_application", "Marca_Modelo") VALUES
  ('6cd620a8-0925-4e84-af13-23ce7f5571ab', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-05-02T20:27:00+00:00', '2026-05-02T22:22:00+00:00', 'AER', '', 'SDE', '', '79', 'MULT-T', 'LV-KJE', 26000, 1, '0.9', '1', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T06:49:58.424146+00:00', 1.9, 1.9, 0, 1.7, 0, 0, 0, 0, 0, 0, 0.9, 0, 1, 0, 1.7, 0, 0, 0, 0, 'B738'),
  ('a8707e1e-22ea-4c50-8e0e-5d49b6c3e4ea', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-05-02T17:46:00+00:00', '2026-05-02T19:44:00+00:00', 'TUC', '', 'AER', '', '79', 'MULT-T', 'LV-KJE', 26000, 1, '2', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T06:47:40.514183+00:00', 2, 2, 0, 1.8, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1.8, 0, 0, 0, 0, 'B738'),
  ('20ea2735-57ec-4d92-9308-657a4596c3bc', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-05-13T00:10:00+00:00', '2026-05-13T02:28:00+00:00', 'AER', '', 'SAL', '', '79', 'MULT-T', 'LV-KJE', 26000, 1, '0', '2.3', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-13T06:25:32.739883+00:00', 2.3, 2.3, 0, 2.1, 0, 0, 0, 0, 0, 0, 0, 0, 2.3, 0, 2.1, 0, 0, 0, 0, 'B738'),
  ('07928e0d-53f1-4180-8c8c-b4d07b1930e2', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-05-02T22:45:00+00:00', '2026-05-03T00:30:00+00:00', 'SDE', '', 'EZE', '', '79', 'MULT-T', 'LV-KJE', 26000, 1, '0', '1.7', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T19:27:17.197323+00:00', 1.7, 1.7, 0, 1.5, 0, 0, 0, 0, 0, 0, 0, 0, 1.7, 0, 1.5, 0, 0, 0, 0, 'B738'),
  ('63ef581b-91ad-4f60-9707-3bb4e20c913b', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-05-13T02:58:00+00:00', '2026-05-13T05:10:00+00:00', 'SAL', '', 'EZE', '', '79', 'MULT-T', 'LV-KJE', 26000, 1, '0', '2.2', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-13T06:26:48.682416+00:00', 2.2, 2.2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 2.2, 0, 2, 0, 0, 0, 0, 'B738'),
  ('8d65c82c-6430-4e71-8a42-6a6c6d6d2e11', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-05-27T10:20:00+00:00', '2026-05-27T11:45:00+00:00', 'CBA', '', 'AER', '', '79', 'MULT-T', 'LV-KJE', 26000, 1, '1.4', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-27T12:47:50.698022+00:00', 1.4, 1.4, 0, 1.2, 0, 0, 0, 0, 0, 0, 1.4, 0, 0, 0, 1.2, 0, 0, 0, 0, 'B738'),
  ('41d27045-0e45-47e7-9e6a-9292dd9b5313', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-05-27T05:58:00+00:00', '2026-05-27T09:53:00+00:00', 'AER', '', 'CBA', '', '79', 'MULT-T', 'LV-KJE', 26000, 1, '0', '3.9', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-27T12:46:35.332864+00:00', 3.9, 3.9, 0, 3.7, 0, 0, 0, 0, 0, 0, 0, 0, 3.9, 0, 3.7, 0, 0, 0, 0, 'B738'),
  ('2036aa3d-b635-4450-bd4b-72887fa3e009', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-06-06T13:01:00+00:00', '2026-06-06T15:10:00+00:00', 'EZE', '', 'DOZ', '', '79', 'MULT-T', 'LV-KJD', 26000, 1, '2.2', '0', '2', '2', '15', 'Matías Miret', '[]'::jsonb, 1, false, '2026-06-07T02:40:30.334694+00:00', 2.2, 2.2, 0, 2, 0, 0, 0, 0, 0, 0, 2.2, 0, 0, 0, 2, 0, 0, 0, 0, 'B738'),
  ('fb51eae6-fcdc-4141-a366-20e15af40f3b', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-06-04T11:43:00+00:00', '2026-06-04T13:52:00+00:00', 'AER', '', 'TUC', '', '79', 'MULT-T', 'LV-KDQ', 26000, 1, '2.2', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-06-04T21:50:17.134707+00:00', 2.2, 2.2, 0, 2, 0, 0, 0, 0, 0, 0, 2.2, 0, 0, 0, 2, 0, 0, 0, 0, 'B738'),
  ('5aed0224-b176-49b5-8f20-66806200ea7c', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-06-04T14:25:00+00:00', '2026-06-04T16:17:00+00:00', 'TUC', '', 'AER', '', '79', 'MULT-T', 'LV-KDQ', 26000, 1, '1.9', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-06-04T21:51:41.518804+00:00', 1.9, 1.9, 0, 1.7, 0, 0, 0, 0, 0, 0, 1.9, 0, 0, 0, 1.7, 0, 0, 0, 0, 'B738'),
  ('aa1edb01-bd0d-4b7f-b656-d8478111adad', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-06-06T18:30:00+00:00', '2026-06-06T20:15:00+00:00', 'DOZ', '', 'AER', '', '79', 'MULT-T', 'LV-KJD', 26000, 1, '1.7', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-06-07T02:53:25.209663+00:00', 1.7, 1.7, 0, 1.5, 0, 0, 0, 0, 0, 0, 1.7, 0, 0, 0, 1.5, 0, 0, 0, 0, 'B738'),
  ('8447572d-9666-4474-b587-28d57d1ac065', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-08T12:50:00+00:00', '2026-04-08T14:36:00+00:00', 'AER', '', 'CBA', '', '79', 'MULT-T', 'LV-KEG', 26000, 1, '1.8', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T17:59:00.846697+00:00', 1.8, 1.8, 0, 1.6, 0, 0, 0, 0, 0, 0, 1.8, 0, 0, 0, 1.6, 0, 0, 0, 0, 'B738'),
  ('7d2dd6e4-e7d2-4f73-85fe-f12aee85c31b', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-03T22:16:00+00:00', '2026-04-04T00:30:00+00:00', 'IGU', '', 'AER', '', '79', 'MULT-T', 'LV-KJE', 26000, 1, '0', '2.2', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T17:57:14.328185+00:00', 2.2, 2.2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 2.2, 0, 2, 0, 0, 0, 0, 'B738'),
  ('e15789bc-99da-4aa5-9f96-5cb533cab9cc', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-08T15:00:00+00:00', '2026-04-08T16:35:00+00:00', 'CBA', '', 'EZE', '', '79', 'MULT-T', 'LV-KEG', 26000, 1, '1.6', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T18:00:04.08842+00:00', 1.6, 1.6, 0, 1.4, 0, 0, 0, 0, 0, 0, 1.6, 0, 0, 0, 1.4, 0, 0, 0, 0, 'B738'),
  ('dac06e40-4961-454a-ab51-fd2f366faadb', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-19T08:50:00+00:00', '2026-04-19T11:14:00+00:00', 'EZE', '', 'SAL', '', '79', 'MULT-T', 'LV-KJD', 26000, 1, '1.4', '1', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T18:01:10.371929+00:00', 2.4, 2.4, 0, 2.2, 0, 0, 0, 0, 0, 0, 1.4, 0, 1, 0, 2.2, 0, 0, 0, 0, 'B738'),
  ('6a21b575-065e-4601-a0b9-e353e000ad91', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-19T13:42:00+00:00', '2026-04-19T15:02:00+00:00', 'CBA', '', 'EZE', '', '79', 'MULT-T', 'LV-KJD', 26000, 1, '1.3', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T18:03:45.649338+00:00', 1.3, 1.3, 0, 1.1, 0, 0, 0, 0, 0, 0, 1.3, 0, 0, 0, 1.1, 0, 0, 0, 0, 'B738'),
  ('7c00b3c4-fa46-48db-af2b-9612f86ef0aa', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-19T11:42:00+00:00', '2026-04-19T13:05:00+00:00', 'SAL', '', 'CBA', '', '79', 'MULT-T', 'LV-KJD', 26000, 1, '1.4', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T18:02:24.62832+00:00', 1.4, 1.4, 0, 1.2, 0, 0, 0, 0, 0, 0, 1.4, 0, 0, 0, 1.2, 0, 0, 0, 0, 'B738'),
  ('9ef55b85-c4dc-4d1e-9e5b-8d24d7bcadd7', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-20T10:40:00+00:00', '2026-04-20T14:10:00+00:00', 'AER', '', 'ECA', '', '79', 'MULT-T', 'LV-KJE', 26000, 1, '3.5', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T18:14:11.959502+00:00', 3.5, 3.5, 0, 3.3, 0, 0, 0, 0, 0, 0, 3.5, 0, 0, 0, 3.3, 0, 0, 0, 0, 'B738'),
  ('87fdac06-3a2b-4175-89e9-a3dae31e25d0', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-20T14:40:00+00:00', '2026-04-20T17:53:00+00:00', 'ECA', '', 'AER', '', '79', 'MULT-T', 'LV-KJE', 26000, 1, '3.2', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T18:15:18.76059+00:00', 3.2, 3.2, 0, 3, 0, 0, 0, 0, 0, 0, 3.2, 0, 0, 0, 3, 0, 0, 0, 0, 'B738'),
  ('4d36bfa2-38fd-457a-9c70-d8d4d5a12fe8', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-22T18:17:00+00:00', '2026-04-22T20:07:00+00:00', 'AER', '', 'CRR', '', '79', 'MULT-T', 'LV-KCE', 26000, 1, '1.8', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T18:16:48.098922+00:00', 1.8, 1.8, 0, 1.6, 0, 0, 0, 0, 0, 0, 1.8, 0, 0, 0, 1.6, 0, 0, 0, 0, 'B738'),
  ('b7d2ef83-d231-49d1-b634-ddbcc6a79ccc', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-22T20:30:00+00:00', '2026-04-22T22:08:00+00:00', 'CRR', '', 'AER', '', '79', 'MULT-T', 'LV-KCE', 26000, 1, '1.6', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T18:17:40.947064+00:00', 1.6, 1.6, 0, 1.4, 0, 0, 0, 0, 0, 0, 1.6, 0, 0, 0, 1.4, 0, 0, 0, 0, 'B738'),
  ('8dc72a75-16cc-40b3-b229-679b3ea57be0', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-22T23:05:00+00:00', '2026-04-23T01:17:00+00:00', 'AER', '', 'SDE', '', '79', 'MULT-T', 'LV-KCE', 26000, 1, '0', '2.2', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T18:18:26.412873+00:00', 2.2, 2.2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 2.2, 0, 2, 0, 0, 0, 0, 'B738'),
  ('ee1c97bb-db97-4a6f-8eeb-9ba1d4d1bad1', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-23T18:25:00+00:00', '2026-04-23T20:01:00+00:00', 'SDE', '', 'AER', '', '79', 'MULT-T', 'LV-KCE', 26000, 1, '1.6', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T18:20:04.977016+00:00', 1.6, 1.6, 0, 1.4, 0, 0, 0, 0, 0, 0, 1.6, 0, 0, 0, 1.4, 0, 0, 0, 0, 'B738'),
  ('39f877ce-6e64-4a5a-bfbc-c56919202c98', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-29T15:20:00+00:00', '2026-04-29T17:38:00+00:00', 'AER', '', 'JUA', '', '79', 'MULT-T', 'LV-KCE', 26000, 1, '2.3', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T18:20:45.001528+00:00', 2.3, 2.3, 0, 2.1, 0, 0, 0, 0, 0, 0, 2.3, 0, 0, 0, 2.1, 0, 0, 0, 0, 'B738'),
  ('3e62d239-885b-44d0-812d-b8836136b41d', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-04-29T18:07:00+00:00', '2026-04-29T19:59:00+00:00', 'JUA', '', 'AER', '', '79', 'MULT-T', 'LV-KCE', 26000, 1, '1.9', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T18:21:39.239725+00:00', 1.9, 1.9, 0, 1.7, 0, 0, 0, 0, 0, 0, 1.9, 0, 0, 0, 1.7, 0, 0, 0, 0, 'B738'),
  ('f02c1d22-836f-413f-9bc1-5c9f4b0ab401', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-05-02T15:10:00+00:00', '2026-05-02T17:14:00+00:00', 'AER', '', 'TUC', '', '79', 'MULT-T', 'LV-KJE', 26000, 1, '2.1', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-05-03T06:55:48.231079+00:00', 2.1, 2.1, 0, 1.9, 0, 0, 0, 0, 0, 0, 2.1, 0, 0, 0, 1.9, 0, 0, 0, 0, 'B738'),
  ('98080f52-8fe6-485b-9a19-b3812aa82db9', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-07-17T00:13:00+00:00', '2026-07-17T02:19:00+00:00', 'JUJ', '', 'AER', '', '79', 'MULT-T', '', 26000, 1, '0', '2.1', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-07-17T20:38:16.373695+00:00', 2.1, 2.1, 0, 1.9, 0, 0, 0, 0, 0, 0, 0, 0, 2.1, 0, 1.9, 0, 0, 0, 0, 'B738'),
  ('1d5f2a26-df39-454e-94d0-472b42f14de9', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-07-17T21:15:00+00:00', '2026-07-17T23:40:00+00:00', 'AER', '', 'JUJ', '', '79', 'MULT-T', 'LV-KEF', 26000, 1, '2.4', '0', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-07-17T20:37:02.719859+00:00', 2.4, 2.4, 0, 2.2, 0, 0, 0, 0, 0, 0, 2.4, 0, 0, 0, 2.2, 0, 0, 0, 0, 'B738'),
  ('a2d1e8f0-6ad1-4457-bb70-f8299d24dc1c', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-07-14T02:38:00+00:00', '2026-07-14T04:58:00+00:00', 'AER', '', 'BAR', '', '79', 'MULT-T', 'LV-KDQ', 26000, 1, '0', '2.3', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-07-15T08:21:27.41913+00:00', 2.3, 2.3, 0, 2.1, 0, 0, 0, 0, 0, 0, 0, 0, 2.3, 0, 2.1, 0, 0, 0, 0, 'B738'),
  ('e3124c4d-84ee-46db-8164-fe4b92e32f2f', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '2026-07-15T05:31:00+00:00', '2026-07-15T07:52:00+00:00', 'BAR', '', 'AER', '', '79', 'MULT-T', 'LV-KDQ', 26000, 1, '0', '2.4', '2', '2', '15', 'Matias Miret', '[]'::jsonb, 1, false, '2026-07-15T08:45:49.678128+00:00', 2.4, 2.4, 0, 2.2, 0, 0, 0, 0, 0, 0, 0, 0, 2.4, 0, 2.2, 0, 0, 0, 0, 'B738');

-- Datos para pending_registrations
INSERT INTO public.pending_registrations ("id", "email", "password_hash", "first_name", "last_name", "license", "dni", "legajo", "created_at") VALUES
  ('a0812f71-ea59-4f1f-b725-ceaf64ff9d09', 'test-amount@mail.com', 'test123', '', '', '', '', '', '2026-06-13T08:18:31.309024+00:00'),
  ('0754c3e8-cae6-491a-87dd-9408403ea240', 'arielbasseterre@outlook.com', '12345678', 'Jose ', 'Velz', 'TLA', '23456123', '99990', '2026-06-14T22:32:14.646735+00:00'),
  ('7ef00cdc-3c3d-479b-b266-cc74d927f03c', 'test@test.com', 'test123', '', '', '', '', '', '2026-06-13T06:13:26.859545+00:00');

-- Datos para user_remote_sessions
INSERT INTO public.user_remote_sessions ("id", "user_id", "session_data", "created_at", "updated_at") VALUES
  ('e2b972df-7063-41fd-a4fe-ceae8de528ba', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '{"cookies":[{"name":".AspNetCore.Antiforgery.rNzFo6qwfiE","path":"/","value":"CfDJ8Cz49cE4E3RIsMmVd0cGfOF0UeYcaGlUCW10zWqWvif7HWjmEafy_nAeutXuKewd0PDOzXHzPw6CK1qWGESh7f40dDTdfcbNYWU1TEcKXarRCnH-JR-pL0t5U4qJDO4QYf_bRYO2TNN6cDmn9Na9J0g","domain":"login.anac.gob.ar","secure":true,"expires":-1,"httpOnly":true,"sameSite":"Strict"},{"name":"idsrv.session","path":"/","value":"d0c1092616931d317547b1bca556def9","domain":"login.anac.gob.ar","secure":true,"expires":-1,"httpOnly":false,"sameSite":"Lax"},{"name":"idsrv","path":"/","value":"CfDJ8Cz49cE4E3RIsMmVd0cGfOHGkLfapHXaWwp8H5SHGvLTVL07xokX-qt57iu4T7N3tJbN5gmathG2M2XiV8LlQPvekWNCrh9rUec5Q5noFEK0rWMtwjF7E0kDRGqFvL127CyQsWN19AmqZ-WHeDUOP7lH1A4SNyxGHHP_DilZIA9teWYaThe8FBNvdj9_b8hCr5rIsPetT1WcrGP-KU-HsY2KnENLES1kiUWBw0r-Ql65sLfdXUZJZ6FBAZQrq-ir15GNT6jlROGl8sIFRrezPppUIlyiRAzGyTfpwLSrdFmXH-OJ-8EhLPRIbqav5w1xE_44FrSyX0LazHFhY9WwDdGWltzaQyYDomA7FtTda05G-PlQWK3yktkc5o61MFsLKSL-CNGDWl9fzeMEdFKIsBatnkokL6WvI16ZSSoGvyp09mxzoDoOxMdpXCwQfp-yvuTPDIuY2d3iIAJitZJw5APYcptpDCGbNaiRV7Eq3_iyWw0VTBG5ztu3Ccnq9CtdpgvD5v7bVk_FU8_R7G-veGBFT6CE1P7JO9t10cmc-WQNWal-hb3HfuUL0cklfb9VeA","domain":"login.anac.gob.ar","secure":true,"expires":-1,"httpOnly":true,"sameSite":"Lax"},{"name":"Auth.ANAC.localhost","path":"/","value":"9587C22E3AC08565BF5AEB63EAE3A0D850C56906E01EBB2BA5DF71351125C9D69AD7C13867FB815E18FB039768953F2B50100D7AC76B09EFC7067A6AEBB1C8E22A577F84AC74C0149A494BA32180290D6474D3EA9D03CCD2DF68F2CE5393084D262FE6D6","domain":"cad.anac.gob.ar","secure":false,"expires":-1,"httpOnly":true,"sameSite":"Lax"}],"origins":[]}'::jsonb, '2026-05-03T16:29:19.01614+00:00', '2026-07-17T20:38:53.563+00:00');

-- Datos para app_config
INSERT INTO public.app_config ("key", "value") VALUES
  ('subscription_amount', '40000');

-- Datos para arms_roster
INSERT INTO public.arms_roster ("id", "user_id", "month", "year", "synced_at", "roster_json", "roster_hash") VALUES
  ('ab753c35-e635-4cc9-8b9e-329cc48a019a', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', 7, 2026, '2026-07-18T03:31:46.322+00:00', '[{"date":"01-Jul-2026","legs":[],"dateISO":"2026-07-01","rawTask":"LEAVE - Dias Libres Adicionales","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"02-Jul-2026","legs":[],"dateISO":"2026-07-02","rawTask":"LEAVE - Dias Libres Adicionales","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"03-Jul-2026","legs":[],"dateISO":"2026-07-03","rawTask":"LEAVE - Dias Libres Adicionales","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"04-Jul-2026","legs":[],"dateISO":"2026-07-04","rawTask":"LEAVE - Dias Libres Adicionales","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"05-Jul-2026","legs":[],"dateISO":"2026-07-05","rawTask":"LEAVE - Dias Libres Adicionales","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"06-Jul-2026","legs":[],"dateISO":"2026-07-06","rawTask":"LEAVE - Dias Libres Adicionales","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"07-Jul-2026","legs":[],"dateISO":"2026-07-07","rawTask":"LEAVE - Dias Libres Adicionales","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"08-Jul-2026","legs":[],"dateISO":"2026-07-08","rawTask":"LEAVE - Dias Libres Adicionales","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"09-Jul-2026","legs":[],"dateISO":"2026-07-09","rawTask":"LEAVE - Dias Libres Adicionales","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"10-Jul-2026","legs":[],"dateISO":"2026-07-10","rawTask":"LEAVE - Dias Libres Adicionales","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"11-Jul-2026","legs":[],"dateISO":"2026-07-11","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"12-Jul-2026","legs":[],"dateISO":"2026-07-12","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"13-Jul-2026","legs":[],"dateISO":"2026-07-13","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"14-Jul-2026","legs":[{"origin":"AEP","blockTime":"02:20","destination":"BRC","flightNumber":"FO5248","reportTimeLoc":"21:54","reportTimeUtc":"00:54","arrivalTimeLoc":"01:58","arrivalTimeUtc":"04:58","crewComplement":[{"name":"(1920) SAULLE JUAN (LS)","role":"OTHER"},{"name":"(1667) BONARDI FEDERICO ()","role":"CC"},{"name":"(2090) CASTRO CAMILA ()","role":"CC"},{"name":"(65) LEVAR CAROLINA ()","role":"PU"},{"name":"(2000) PONS LEILA ()","role":"CC"}],"departureTimeLoc":"23:38","departureTimeUtc":"02:38"}],"dateISO":"2026-07-14","rawTask":"OP - (RS)","isFlight":true,"eventType":"FLIGHT_OP","dailyBlockTotal":"02:20"},{"date":"15-Jul-2026","legs":[{"origin":"BRC","turnTime":"00:33","blockTime":"02:21","destination":"AEP","flightNumber":"FO5249","reportTimeLoc":"","reportTimeUtc":"","arrivalTimeLoc":"04:52","arrivalTimeUtc":"07:52","crewComplement":[{"name":"(1920) SAULLE JUAN (LS)","role":"OTHER"},{"name":"(1667) BONARDI FEDERICO ()","role":"CC"},{"name":"(2090) CASTRO CAMILA ()","role":"CC"},{"name":"(65) LEVAR CAROLINA ()","role":"PU"},{"name":"(2000) PONS LEILA ()","role":"CC"}],"isContinuation":true,"departureTimeLoc":"02:31","departureTimeUtc":"05:31"}],"dateISO":"2026-07-15","rawTask":"OP - (RS)","isFlight":true,"eventType":"FLIGHT_OP","dailyBlockTotal":"02:21"},{"date":"16-Jul-2026","legs":[{"origin":"AEP","blockTime":"02:25","destination":"JUJ","flightNumber":"FO5182","reportTimeLoc":"16:15","reportTimeUtc":"19:15","arrivalTimeLoc":"20:40","arrivalTimeUtc":"23:40","crewComplement":[{"name":"(1435) OVIEDO ADRIAN (LS)","role":"OTHER"},{"name":"(400) ELEONORI CRISTOPHER ()","role":"PU"},{"name":"(1250) MOLINA NADIA ()","role":"CC"},{"name":"(1671) RABAZZA ISABEL ()","role":"CC"},{"name":"(1827) VELEHORSKI FLORENCIA ()","role":"CC"}],"departureTimeLoc":"18:15","departureTimeUtc":"21:15"},{"origin":"JUJ","turnTime":"00:33","blockTime":"02:06","destination":"AEP","flightNumber":"FO5183","reportTimeLoc":"","reportTimeUtc":"","arrivalTimeLoc":"23:19","arrivalTimeUtc":"02:19","crewComplement":[{"name":"(1435) OVIEDO ADRIAN (LS)","role":"OTHER"},{"name":"(400) ELEONORI CRISTOPHER ()","role":"PU"},{"name":"(1250) MOLINA NADIA ()","role":"CC"},{"name":"(1671) RABAZZA ISABEL ()","role":"CC"},{"name":"(1827) VELEHORSKI FLORENCIA ()","role":"CC"}],"departureTimeLoc":"21:13","departureTimeUtc":"00:13"}],"dateISO":"2026-07-16","rawTask":"OP - (RS)","isFlight":true,"eventType":"FLIGHT_OP","dailyBlockTotal":"04:31"},{"date":"17-Jul-2026","legs":[],"dateISO":"2026-07-17","rawTask":"STB - STBY","remarks":"","isFlight":false,"eventType":"STANDBY","endTimeLoc":"23:59","endTimeUtc":"02:59","startTimeLoc":"16:00","startTimeUtc":"19:00","dailyBlockTotal":"00:00"},{"date":"18-Jul-2026","legs":[],"dateISO":"2026-07-18","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"19-Jul-2026","legs":[],"dateISO":"2026-07-19","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"20-Jul-2026","legs":[],"dateISO":"2026-07-20","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"21-Jul-2026","legs":[],"dateISO":"2026-07-21","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"22-Jul-2026","legs":[],"dateISO":"2026-07-22","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"23-Jul-2026","legs":[],"dateISO":"2026-07-23","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"24-Jul-2026","legs":[],"dateISO":"2026-07-24","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"25-Jul-2026","legs":[],"dateISO":"2026-07-25","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"26-Jul-2026","legs":[],"dateISO":"2026-07-26","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"27-Jul-2026","legs":[],"dateISO":"2026-07-27","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"28-Jul-2026","legs":[],"dateISO":"2026-07-28","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"29-Jul-2026","legs":[],"dateISO":"2026-07-29","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"30-Jul-2026","legs":[],"dateISO":"2026-07-30","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"},{"date":"31-Jul-2026","legs":[],"dateISO":"2026-07-31","rawTask":"LEAVE - Suspensión 223","remarks":"","isFlight":false,"eventType":"LEAVE","dailyBlockTotal":"00:00"}]'::jsonb, 'a2f8565dc7e3c1727088d849df8909e40295eabb0c771cce8f42ae74d18b6a37');

-- Datos para arms_sessions
INSERT INTO public.arms_sessions ("id", "user_id", "session_data", "created_at", "updated_at", "arms_username") VALUES
  ('bbd38e8b-6748-4ab8-8efb-5dca1ab53fc6', '3bee64a2-406e-4848-b5cb-b900d7234189', '{"cookies":[{"name":"ASP.NET_SessionId","path":"/","value":"qyuopxdry0f3dlznphuawcn3","domain":"fbz.arms.aero","secure":false,"expires":-1,"httpOnly":true,"sameSite":"Lax"},{"name":".ASPXAUTH","path":"/","value":"CC7D4EFE867504959F7365DD48BEBFC06007412CE176C3763C271F098E777E92E66052F83D06C1B052957C91CA0A6ABC3A4D76878C7868D1726E19E3EB5DA18951AE0F701C2D9FC60113C218B83BECB663F4D5CAD80C8860B959A7EF9E2FA591200D2BFC9BFEE643EC860E7AE7812F09D518943CBE8BB1E9FEFEFF1BEC5AFAA6FD0E03E91A5883855ED3B3E2F578F7A67EF2B803301897A408711EA8148E7695","domain":"fbz.arms.aero","secure":false,"expires":-1,"httpOnly":false,"sameSite":"Lax"}],"origins":[]}'::jsonb, '2026-06-28T02:29:01.501936+00:00', '2026-06-28T02:29:20.685+00:00', '1719'),
  ('8b0e962c-0a31-45fe-bc0c-8e1f18410759', 'd72b2ab2-13fc-4953-81f9-db6303189e95', '{"cookies":[{"name":"ASP.NET_SessionId","path":"/","value":"sygpw1dznskxwjazvhgb3mbe","domain":"fbz.arms.aero","secure":false,"expires":-1,"httpOnly":true,"sameSite":"Lax"},{"name":".ASPXAUTH","path":"/","value":"F74F84749A58F965C6DD90724B8158D981614C8FB5499FB549E89D6375900D12E803357E202626947820CB95EC1F8403BA548F420209DC8AFDA3F0B2B3504505AD9E310B135101A445A002312BEF33FC42685957DED2F37CF9A86C27E72569115502523CEE5B80DC6B8F2E53DCA8C909127AF2633476466CF830896B984DFDBDD84719CD81888700CB44CFE4522A8B794914344792DFA45E1AAE2624BA0E0A03","domain":"fbz.arms.aero","secure":false,"expires":-1,"httpOnly":false,"sameSite":"Lax"}],"origins":[]}'::jsonb, '2026-06-28T19:08:07.191802+00:00', '2026-07-12T16:41:51.277+00:00', '1422'),
  ('73c5293a-edf4-4504-b94f-e022a41b39ca', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '{"cookies":[{"name":"ASP.NET_SessionId","path":"/","value":"rp3s1i1nrwtgb2ulfkwmfbcr","domain":"fbz.arms.aero","secure":false,"expires":-1,"httpOnly":true,"sameSite":"Lax"},{"name":".ASPXAUTH","path":"/","value":"FA1CCC9ECC55BD21B38746CA5BF8A07680531D7BCF5B7EB7B4B69338CC7791CA8021888A434C0396481767BCA677CCB9A41CD861B005FD324EBA18E4E9556C2CF76A07A12696A483ADBA1B3D0EA33BD477FF9B895310A8B8E8BC3595B65EA301D818F5836D0B18453812F2476F2294DEA8A254346D07270E5DC69CA54B7EC18A667199BD253AD17E18143EFE456500B674531B0785EE08ECF09DB381CB739980","domain":"fbz.arms.aero","secure":false,"expires":-1,"httpOnly":false,"sameSite":"Lax"}],"origins":[]}'::jsonb, '2026-06-28T02:22:16.937132+00:00', '2026-07-18T03:31:46.759+00:00', '1719'),
  ('51f614ed-07aa-4460-855c-0432a9d78202', '61ad7088-ae59-4d04-ab3b-1a94ce1316b8', '{"cookies":[{"name":"ASP.NET_SessionId","path":"/","value":"0ovyz3xef2zcduw21tga1kbi","domain":"fbz.arms.aero","secure":false,"expires":-1,"httpOnly":true,"sameSite":"Lax"},{"name":".ASPXAUTH","path":"/","value":"82FBF31223BEB73530C111B1A10EDEECBF21A41A6B199271107BF24402C0DFF847DD6B1BBC4BECD78312F126139941DD0B0FAC85736556A1FF8F50BE7D04BC61F637182347915402668F7D8F8C1BF0A562B7856764E4A79339ED38D7842CB1D60CB3052A6067493E3623B689E64B167F6821D5541541DCC6AD98193271D272FA59BE367ED297CFE12A076BBB3E0DCCF571ECB23125615565A3C0DE7C90F88FED","domain":"fbz.arms.aero","secure":false,"expires":-1,"httpOnly":false,"sameSite":"Lax"}],"origins":[]}'::jsonb, '2026-07-15T08:31:44.019863+00:00', '2026-07-15T08:31:43.948+00:00', '65'),
  ('0a4f5f55-932b-4ac2-82c2-547085805f61', '2289fbc0-fc71-4e04-80ca-a023de7839a5', '{"cookies":[{"name":"ASP.NET_SessionId","path":"/","value":"w1oe2mzxyza2zmnswcmio5gf","domain":"fbz.arms.aero","secure":false,"expires":-1,"httpOnly":true,"sameSite":"Lax"},{"name":".ASPXAUTH","path":"/","value":"EA9BAE5BA66A4B40CEAD764713CAB7F8EBC15D3280D8BB963B874C344278F89B483161FF2181B9DC3E3B892317474DAE48E193A5BCE236D77BCE4F51CC9A0BFC4C8E6426CEFB4D6BEB69EEE2935D304E9A0808B450277B84134876585EC5BFDC5245386AE8CF8C570F1CB8D92797891DA4B9B1ECD617D4C84BEC45B455A46F774F8CA0A977BADEA672FB87ACDD8F22E662C91C72BEEFE549CA7B1A87F818111E","domain":"fbz.arms.aero","secure":false,"expires":-1,"httpOnly":false,"sameSite":"Lax"}],"origins":[]}'::jsonb, '2026-07-17T17:58:44.062736+00:00', '2026-07-17T17:58:43.866+00:00', '1435');

-- Datos para bug_reports
INSERT INTO public.bug_reports ("id", "description", "created_at", "title", "user_email") VALUES
  ('87e8d60c-0cae-4316-aebe-c9ff289bf8df', 'Test de envio de reporte', '2026-07-18T03:15:33.416534+00:00', 'Test de envio de reporte', 'arielbasseterre@gmail.com'),
  ('ded38a65-0e1c-4e50-822e-3887802af790', 'Prueba vamos a ver!!', '2026-07-18T03:38:45.288326+00:00', 'La doda', 'valeriabasseterre@hotmail.com');

-- Sin datos para push_tokens

-- Datos para calendar_tokens
INSERT INTO public.calendar_tokens ("id", "user_id", "token", "label", "settings", "created_at", "revoked_at", "user_email") VALUES
  ('f8456d01-5f11-4434-9df8-3e147934d5e8', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', '518c6356b4ff9b082a5750f0b517db224db9762805e09cc0', 'personal', '{"excludeGTR":false,"excludeNDA":false,"excludeOTH":false,"excludeCrew":true,"excludeLeave":false,"excludeDayOff":false,"excludeReport":false,"excludeDebrief":false,"excludeLayover":false,"excludeStandby":false,"excludeDeadhead":false,"aggregateFlights":true,"excludeSimulator":false,"layover30MinOnly":true,"flightEventFormat":"route_times","flightTitleFormat":"route_flight","postFlightMinutes":60,"reportEventFormat":"type_only","reportTitleFormat":"type_info","exportTodayOnwards":true,"flightLocationFormat":"times_flight","reportLocationFormat":"airport_only","flightDescriptionFormat":"city_icao","reportDescriptionFormat":"crew_info"}'::jsonb, '2026-06-27T16:46:46.438019+00:00', NULL, 'arielbasseterre@gmail.com'),
  ('af7cd29d-fc48-4f7d-80e7-8b8b12633c61', 'd72b2ab2-13fc-4953-81f9-db6303189e95', 'b6f251602c28a1c16bdcdf6279032eee125dbf5d630acf49', 'Flybondi Pedro', '{"excludeGTR":false,"excludeNDA":false,"excludeOTH":false,"excludeCrew":false,"excludeLeave":false,"excludeDayOff":false,"excludeReport":false,"excludeDebrief":false,"excludeLayover":false,"excludeStandby":false,"excludeDeadhead":false,"aggregateFlights":true,"excludeSimulator":false,"layover30MinOnly":false,"flightEventFormat":"route_flight_times","flightTitleFormat":"route_flight","postFlightMinutes":30,"reportEventFormat":"type_info","reportTitleFormat":"type_info","exportTodayOnwards":false,"flightLocationFormat":"times_flight","reportLocationFormat":"time_utc","flightDescriptionFormat":"city_icao","reportDescriptionFormat":"crew_info"}'::jsonb, '2026-06-27T16:55:06.506208+00:00', NULL, 'pedromorelli72744@hotmail.com'),
  ('81c46b7c-56d8-42c3-81e6-51920e092a64', '2cc699b7-38e2-4499-89a2-e2c9f1b63129', 'f094a9dcb101aeebd2c3b9f380fa95958febf7329ce92d0a', 'Valeria', '{"excludeGTR":false,"excludeNDA":false,"excludeOTH":false,"excludeCrew":false,"excludeLeave":false,"excludeDayOff":false,"excludeLayover":false,"excludeStandby":false,"aggregateFlights":false,"flightEventFormat":"route_flight_times","postFlightMinutes":0,"reportEventFormat":"type_info","exportTodayOnwards":false}'::jsonb, '2026-07-18T03:18:58.791575+00:00', NULL, 'arielbasseterre@gmail.com');

SET session_replication_role = 'origin';
